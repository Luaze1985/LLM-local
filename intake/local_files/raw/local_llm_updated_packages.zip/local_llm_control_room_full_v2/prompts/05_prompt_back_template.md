---
title: Prompt back template
date: 2026-04-06
status: draft
tags: [prompt, back, template]
category: architecture
chunk_type: prompt
---

# Prompt-back template

```text
Mål slik jeg forstår det:

Foreslått rute nå:

Hvorfor denne ruten:

Minste nyttige neste steg:

Det jeg trenger av deg før jeg går bredere:
```
