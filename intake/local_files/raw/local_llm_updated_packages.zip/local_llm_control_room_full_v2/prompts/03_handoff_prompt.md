---
title: Handoff prompt to Claude or Codex
date: 2026-04-06
status: draft
tags: [prompt, handoff, claude, codex]
category: architecture
chunk_type: prompt
---

# Handoff prompt

```text
Nedenfor er et lokalt forarbeid. Bruk dette som grunnlag, ikke som ufeilbarlig fasit.

Mål:
{{goal}}

Valgt område:
{{area}}

Hva lokal analyse allerede har funnet:
{{known}}

Hva som fortsatt er uklart eller risikabelt:
{{unknowns}}

Ønsket neste steg fra deg:
{{next_step}}

Før du foreslår endringer, skal du:
1. verifisere hva som virker sannsynlig riktig
2. peke på antakelser som må testes
3. foreslå minste nyttige endring først
```
