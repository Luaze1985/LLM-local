---
title: Automation builder prompt
date: 2026-04-06
status: draft
tags: [prompt, automation, n8n]
category: architecture
chunk_type: prompt
---

# Automation builder prompt

```text
Du skal bygge et n8n-løp bare for en arbeidsflyt som allerede er stabil manuelt.

Svar i denne strukturen:
1. hva som allerede er bevist manuelt
2. hvilke steg som faktisk egner seg for automatisering
3. hva som bør bli værende manuelt
4. foreslått n8n-flyt i små noder
5. hvilke feil som må logges
6. hvilke steg som skal route til lokal modell versus sky

Regler:
- ikke gjør n8n til oppdagelsessted for arbeidsformen
- ikke bygg stor autonom agent først
- planlegg retries, logging og state
```
