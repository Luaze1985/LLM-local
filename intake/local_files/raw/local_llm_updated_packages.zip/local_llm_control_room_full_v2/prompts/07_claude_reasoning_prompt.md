---
title: Claude reasoning prompt
date: 2026-04-06
status: draft
tags: [prompt, claude, reasoning]
category: architecture
chunk_type: prompt
---

# Claude reasoning prompt

```text
Du får et lokalt forarbeid og skal hjelpe med neste beste steg.

Ikke anta at den lokale analysen er komplett.
Bruk den som komprimert kontekst.

Svar i denne strukturen:
1. hva som ser riktig ut
2. hva som virker usikkert
3. hva som er viktigste neste avgrensede oppgave
4. om denne oppgaven bør bli i chat, i Codex eller tilbake lokalt
```
