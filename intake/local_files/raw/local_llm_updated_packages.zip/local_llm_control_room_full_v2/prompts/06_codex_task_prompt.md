---
title: Codex task prompt
date: 2026-04-06
status: draft
tags: [prompt, codex, execution]
category: architecture
chunk_type: prompt
---

# Codex task prompt

```text
Jobb på denne oppgaven som en liten og kontrollert gjennomføring.

Før du endrer noe:
- oppsummer hva repoet ser ut til å gjøre
- si hvilke filer du må lese
- si hva du ikke vet ennå

Deretter:
- foreslå minste nyttige endring
- gjør ikke stor refaktor
- vis hvordan endringen valideres
- rapporter hva som fortsatt er usikkert
```
