---
title: Local LLM control room full pack
date: 2026-04-06
status: revised
tags: [local-llm, workflow, automation, hybrid, claude, codex, n8n, github-qa]
category: architecture
chunk_type: packet
---

# Local LLM control room

Denne pakken samler hele arbeidsformen i ett sted.

Denne versjonen er oppdatert etter GitHub-QA mot 34 relevante repoer og er strammet inn til en klarere styringsmodell.

## Fast anbefalt standardstack

- lokal motor: Ollama
- første modell: Qwen3-Coder
- lokal arbeidsform: liten controller og terminal først
- repoarbeid: Aider- eller Cline-lignende arbeidsmønster
- hybrid gateway: LiteLLM ved behov
- bred lokal backend-reserve: LocalAI
- desktopreserve: Jan
- tyngre agentplattform: OpenHands senere
- automatisering: n8n først når manuell flyt er stabil

## Kjerneprinsipp

Start alltid med en liten og kontrollert arbeidsenhet.

Rekkefølgen er:

1. scan og forstå lokalt
2. avgjør om oppgaven kan bli lokalt
3. send bare det som er verdt det til Claude eller Codex
4. automatiser først når den manuelle flyten virker

## Hva som er nytt i denne versjonen

- GitHub-QA som eget beslutningslag
- oppdatert modellrangering for april 2026
- konkret anbefaling for `LLM-local`
- tydeligere grense mellom lokal, hybrid og n8n
- samlet oppdatert zip-pakke

## Anbefalt leserekkefølge

1. `docs/01_control_room_overview.md`
2. `docs/02_route_decision_matrix.md`
3. `docs/03_local_repo_analysis_workflow.md`
4. `docs/04_hybrid_local_claude_codex.md`
5. `docs/05_n8n_automation_blueprint.md`
6. `docs/11_github_qa_validation.md`
7. `docs/12_model_and_stack_recommendation_april_2026.md`
8. `docs/13_llm_local_repo_handoff.md`
9. `prompts/`
10. `scripts/`
