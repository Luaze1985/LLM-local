---
title: Agent roles and responsibilities
date: 2026-04-06
status: draft
tags: [agents, roles, routing]
category: architecture
chunk_type: process
---

# Agent roles

## 1. Router

Velger spor:

- lokal
- hybrid
- sky
- senere n8n

Router skal ikke løse oppgaven. Router skal bare velge rett arbeidsform.

## 2. Scanner

Leser repo og lager første oversikt.

Output:

- README-status
- hovedmapper
- sannsynlig viktige filer
- støy som bør ignoreres

## 3. Analyst

Jobber lokalt på liten arbeidsenhet.

Output:

- forklaring
- filrolle
- usikkerhet
- én liten forbedring eller neste steg

## 4. Handoff writer

Gjør råfunn om til kort skyklar pakke.

Output:

- mål
- valgt område
- hva som er kjent
- hva som er uklart
- hvorfor sky er valgt

## 5. Automation builder

Brukes først når rutinen er bevist.

Output:

- n8n-løp
- trigger
- kølogikk
- rapportering

## Viktig regel

Ingen agent får hoppe direkte fra scan til stor implementering uten at prompt-back-protokollen er passert.
