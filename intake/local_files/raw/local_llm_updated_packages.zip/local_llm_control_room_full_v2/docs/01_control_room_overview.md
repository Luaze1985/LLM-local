---
title: Control room overview
date: 2026-04-06
status: revised
tags: [overview, control-room, workflow]
category: architecture
chunk_type: process
---

# Control room overview

## Hva dette faktisk er

Dette er ikke én agent.

Det er et styringsrom for hvordan du bruker lokale modeller, Claude, Codex og senere n8n uten å miste kontroll på kontekst, stopp, kostnad og fremdrift.

## Den oppdaterte kjernelogikken

GitHub-QA-en peker tydelig på at arbeidsformen bør bygges i denne rekkefølgen:

1. lokal runtime
2. lokal repoanalyse
3. hybrid håndoff
4. senere automatisering

Det betyr i praksis:

- Ollama først
- Qwen3-Coder først
- liten controller først
- Aider/Cline-lignende arbeidsmønster før tyngre agentplattformer
- n8n først når flyten er bevist

## De fire sporene

### Spor A – Ren lokal arbeidsflyt

Brukes når målet er:

- forstå repoet
- forklare README og nøkkelfiler
- lage filkart
- finne små forbedringer
- forberede håndoff

### Spor B – Hybrid lokal + Claude/Codex

Brukes når lokal modell har gjort nok av grunnarbeidet, men oppgaven krever:

- bedre resonnering
- flerfilsendringer
- større trygghet i kodeendringer
- sterkere patch- og refaktorkvalitet

### Spor C – n8n-automatisering

Brukes når arbeidsformen allerede er kjent og repeterbar:

- daglig scanning
- behandling av nye filer
- ruting mellom lokal og sky
- rapportering og vedvarende kø

### Spor D – Agent- og promptlag

Brukes for å hindre at verktøyene hopper for langt frem.

Dette laget skal:

- stille riktige motspørsmål
- velge riktig rute
- be om minste nyttige neste steg
- dokumentere hvorfor en rute ble valgt

## Hovedregel

Ikke begynn med automatisering.

Begynn med en liten manuell flyt som er så god at den fortjener å bli automatisert.
