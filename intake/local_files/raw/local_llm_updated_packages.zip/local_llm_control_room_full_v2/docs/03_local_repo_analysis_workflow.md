---
title: Local repo analysis workflow
date: 2026-04-06
status: revised
tags: [local, repo, analysis, workflow]
category: architecture
chunk_type: process
---

# Local repo analysis workflow

## Formål

Gi en lokal modell en trygg og nyttig jobb uten at den drukner i repoet.

## Standardstack

- runtime: Ollama
- modell: Qwen3-Coder først
- reserve: Qwen3-Coder-30B-A3B-Instruct eller Qwen2.5-Coder
- reserve-runtime ved bredere behov: LocalAI
- desktopreserve: Jan

## Standardløp

### Steg 1 – Scan

- finn README
- finn nøkkelfiler
- ignorer støy: build-mapper, binære filer, store avhengighetsmapper, cache

### Steg 2 – Velg arbeidsenhet

Start med én av disse:

- README alene
- README + én sentral fil
- én sentral fil alene

### Steg 3 – Be modellen gjøre én ting

Eksempler:

- forklar prosjektet presist
- forklar hva denne filen gjør
- pek på én uklarhet i strukturen
- foreslå én liten forbedring med lav risiko

### Steg 4 – Valider output

Sjekk:

- kom svaret tilbake
- er det konkret
- stemmer det med filen
- er det kort nok til å brukes videre
- er det verdt å lagre som håndoff

### Steg 5 – Lagre state

Lagre minst:

- hvilke filer som ble lest
- hva modellen mente
- hva som ble nyttig
- hva som feilet
- neste beste steg

## Praktisk arbeidsenhet

Den sikreste minste arbeidsenheten er:

- 1 oppgave
- 1 fil
- 1 strukturert respons

Ikke gå videre til flere filer før dette er stabilt.

## Output som bør finnes etter en lokal pass

- repo summary
- file map
- risky areas
- likely next step
- candidate for cloud handoff: ja eller nei
