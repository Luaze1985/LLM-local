---
title: Prompt back protocol
date: 2026-04-06
status: draft
tags: [prompt-back, protocol, control]
category: architecture
chunk_type: process
---

# Prompt-back protocol

## Formål

Tvinge agenten til å stoppe opp og spørre tilbake før den velger en for stor eller feil rute.

## Regelen

Før agenten gjør mer enn en liten analyse, skal den svare med:

1. hva den tror du egentlig vil oppnå
2. hvilken rute den vil velge
3. hvorfor akkurat den ruten er riktig nå
4. hva minste nyttige neste steg er
5. hvilke 2–4 spørsmål den trenger svar på hvis usikkerheten er høy

## Hvis usikkerheten er lav

Agenten skal ikke blokkere.
Den skal velge standardrute og forklare antakelsen kort.

## Hvis usikkerheten er høy

Agenten skal spørre tilbake før den gjør noe tungt.

## Når agenten må spørre

- når det er uklart om målet er lokal test, hybrid eller automatisering
- når oppgaven ser større ut enn én fil eller ett avgrenset område
- når den er i ferd med å foreslå n8n eller tung infrastruktur for tidlig
- når den vil sende mye råkontekst til sky

## Standard prompt-back-mal

- Mål slik jeg forstår det:
- Foreslått rute nå:
- Hvorfor:
- Minste nyttige neste steg:
- Det jeg trenger av deg før jeg går bredere:
