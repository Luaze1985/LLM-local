---
title: Control limits and stop rules
date: 2026-04-06
status: draft
tags: [limits, stop-rules, controller]
category: architecture
chunk_type: policy
---

# Control limits and stop rules

## Inputgrenser

Start med:

- 1 oppgave
- 1 fil
- kort README eller utdrag
- strukturert output

## Stoppsignaler

- timeout
- tom respons
- repetitiv respons
- generisk respons uten filforankring
- feil format
- to mislykkede forsøk på samme steg

## Tiltak

Ved første feil:

- kortere prompt
- mindre input
- tydeligere output-format

Ved andre feil:

- del opp oppgaven
- eller route til sky

## Forbud i tidlig fase

- store patcher
- mange filer samtidig
- automatisk commit
- usynlig agentløkke uten state
