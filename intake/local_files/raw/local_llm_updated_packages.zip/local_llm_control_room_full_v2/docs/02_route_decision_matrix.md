---
title: Route decision matrix
date: 2026-04-06
status: revised
tags: [routing, matrix, local, hybrid, n8n]
category: architecture
chunk_type: decision
---

# Route decision matrix

## Standard valg nå

### Velg lokal når

- du skal forstå et repo
- du skal lese README og 1–3 filer
- du vil lage filkart eller moduloversikt
- du vil finne én liten forbedring
- du vil teste om oppgaven i det hele tatt er verdt mer arbeid

**Anbefalt stack**
- Ollama
- Qwen3-Coder
- liten controller
- state og rapport per steg

### Velg hybrid når

- lokal modell forstår repoet, men ikke bør gjøre endringen alene
- du trenger bedre kvalitet på kodeforslag
- du vil minimere skykostnad ved å sende bare oppsummert kontekst videre
- du skal gjøre endringer som berører flere filer eller mer usikre deler av systemet

**Anbefalt ekstra lag**
- LiteLLM som gateway når du vil samle lokal og sky under ett API
- Claude for vurdering og struktur
- Codex for konkret implementering

### Velg sky direkte når

- oppgaven er høy risiko
- oppgaven er tidskritisk
- lokal modell feiler to ganger på samme steg
- du trenger solid flerfilsresonnering med en gang

### Velg n8n når

- du har samme type jobb igjen og igjen
- du vil kjøre batch på nye filer
- du vil ha logging, kø og planlagt kjøring
- du allerede vet hva som skal skje i hvert steg

## Ikke velg n8n når

- du fortsatt prøver å finne ut hva som er riktig arbeidsflyt
- du ikke vet hva som teller som feil eller suksess
- du fortsatt endrer prompt og arbeidsenhet fra dag til dag
