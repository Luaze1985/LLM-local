---
title: LLM-local repo handoff
date: 2026-04-06
status: final
tags: [github, handoff, llm-local]
category: architecture
chunk_type: handoff
---

# LLM-local repo handoff

Dette notatet er laget for repoet `Luaze1985/LLM-local`.

## Formål

Gjøre repoet til et rent hjem for lokal repoanalyse og hybrid arbeidsflyt, uten å blande inn for mye automatisering for tidlig.

## Hva som bør inn først

### Kjerne
- `README.md`
- `docs/`
- `prompts/`
- `scripts/`
- enkel `reference/` med lokal testcontroller

### Bør beskrive tydelig
- hvorfor repoet finnes
- hvorfor lokal controller kommer før agentplattform
- hvorfor n8n kommer senere
- hvilken standardstack som er valgt

## Foreslått standardstack i repoet

- runtime: Ollama
- modell: Qwen3-Coder
- reserve: LocalAI
- hybrid gateway: LiteLLM
- terminal og liten controller først
- n8n senere

## Første commit-blokker

### Blokk 1 – grunnstruktur
- legg inn README
- legg inn docs for lokal, hybrid og n8n senere
- legg inn referansecontroller

### Blokk 2 – QA og beslutning
- legg inn GitHub-QA-rapport
- legg inn modellrangering
- legg inn route decision matrix

### Blokk 3 – praktisk test
- legg inn enkel PowerShell-starter
- legg inn eksempelrapport
- legg inn tydelig “første test” guide

## Hva som ikke bør inn først

- tung agentplattform
- full autonom patching
- stor workflow-orkestrering
- repo-wide batchløp uten state og validering
