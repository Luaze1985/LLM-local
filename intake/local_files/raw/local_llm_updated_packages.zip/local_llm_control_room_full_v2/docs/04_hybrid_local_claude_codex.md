---
title: Hybrid local plus Claude Codex workflow
date: 2026-04-06
status: revised
tags: [hybrid, claude, codex, handoff]
category: architecture
chunk_type: process
---

# Hybrid local + Claude/Codex

## Formål

Bruke lokal modell til billig og kontrollert grunnarbeid, og bruke Claude eller Codex der kvaliteten må være høyere.

## Prinsipp

Lokal modell skal ikke erstatte Claude eller Codex.
Den skal redusere hva de trenger å lese og tenke gjennom.

## God arbeidsdeling

### Lokal modell gjør

- scan av repo
- forklaring av README
- filkart og moduloversikt
- første pass på små filer
- identifisering av sannsynlig viktigste fil eller område
- første utkast til håndoff-notat

### Claude eller Codex gjør

- flerfilsresonnering
- arkitekturvalg med høy usikkerhet
- patcher og refaktorer
- testorienterte endringer
- mer krevende feilretting
- integrering av flere moduler eller deler

## Teknisk mellomlag

Når du vil ha ett felles API-lag mellom lokal og sky, bruk LiteLLM.
Når du vil ha bredere lokal backend-støtte eller annen maskinvare, vurder LocalAI.

## Handoff-pakke

Når du går fra lokal til sky, bør du ikke sende rå dump.

Send bare dette:

- kort prosjektoppsummering
- hvilke filer som er viktigst
- hva lokal modell fant
- hva som er uklart eller risikabelt
- eksakt ønsket oppgave videre

## Handoff-format

Bruk fem felter:

1. mål
2. valgt område
3. hva som allerede er forstått
4. hva som er usikkert
5. ønsket neste steg

## Når du velger Claude fremfor Codex

- du trenger bedre forklaring, resonnering og strukturering
- oppgaven er mer arkitektur- eller dokumenttung
- du vil ha bedre hjelp til å vurdere usikkerhet

## Når du velger Codex fremfor Claude

- du vil raskt inn i kodeendring og testing
- du har et klart repo og en tydelig oppgave
- du vil ha høy fart i konkret implementering
