---
title: Full stack workflow map
date: 2026-04-06
status: draft
tags: [workflow, map, local, hybrid, automation]
category: architecture
chunk_type: map
---

# Full stack workflow map

```text
Idea or repo
  -> Router
    -> Local scan
      -> Local analysis
        -> Decision
          -> Stay local
          -> Handoff to Claude/Codex
          -> Park for later
          -> Automate in n8n when stable
```

## Praktisk tolkning

- ikke alle oppgaver skal til sky
- ikke alle oppgaver skal automatiseres
- lokal modell skal være første filter og første arbeidslag
- n8n skal være et senere driftslag
