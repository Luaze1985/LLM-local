---
title: n8n automation blueprint
date: 2026-04-06
status: revised
tags: [n8n, automation, blueprint]
category: architecture
chunk_type: process
---

# n8n automation blueprint

## Formål

Automatisere det som allerede er bevist manuelt.

## Fast regel

n8n er ikke første arbeidsflate for repoanalyse.
n8n er orkestreringslaget du legger på etter at:

- lokal scanning virker
- validering er tydelig
- håndoff-pakken er stabil
- du vet hva som er feil og hva som er suksess

## Første gode n8n-løp

### Trigger

- schedule: hver morgen
- eller webhook: når nye filer legges til

### Scan

- finn nye filer i lokal mappe eller synket område
- filtrer ut store og irrelevante filer

### Route

- små, enkle filer til lokal modell
- bare høyverdi- eller feilsaker til sky

### Process

- bygg liten prompt
- kall lokal modell
- lagre strukturert svar

### Validate

- hvis respons mangler eller er dårlig: marker som retry eller manuell vurdering
- hvis respons er god: skriv markdown-notat eller rapport

### Report

- dagens nye filer
- hva som ble analysert
- hva som ble hoppet over
- hva som trenger Claude eller Codex

## Ikke la n8n gjøre dette i versjon 1

- full autonom patching
- hele repoer i én omgang
- avanserte agentløkker
- fri planlegging uten state og validering

## Målarkitektur senere

- n8n som orkestrering
- lokal controller som analysearbeider
- Claude eller Codex som selective escalation
- rapporter som markdown i fast mappe
