---
title: Trigger questions for agents
date: 2026-04-06
status: draft
tags: [questions, triggers, routing]
category: architecture
chunk_type: checklist
---

# Trigger questions

Bruk disse før agenten går videre.

## For routing

- Er målet å forstå repoet eller å endre det?
- Er oppgaven liten nok til å bli lokal først?
- Trenger du kvalitet, fart eller null kostnad mest akkurat nå?

## For hybrid

- Hva er den ene tingen lokal modell allerede har avklart?
- Hva er det du ikke stoler på at lokal modell gjør godt nok?
- Hvilken konkret del skal Claude eller Codex overta?

## For n8n

- Er dette en oppgave som går igjen?
- Vet du allerede hvilke steg som skal automatiseres?
- Vet du hva som teller som feil og hva som teller som bestått?

## For repoanalyse

- Hvilket repo starter vi med?
- Holder det å lese README først?
- Skal vi bare forklare, eller også finne én liten forbedring?
