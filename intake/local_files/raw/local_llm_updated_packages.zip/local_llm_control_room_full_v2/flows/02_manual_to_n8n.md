---
title: Manual to n8n flow
date: 2026-04-06
status: draft
tags: [flow, manual, n8n]
category: architecture
chunk_type: flow
---

# Manual to n8n flow

1. Definer hva som allerede virker manuelt
2. Lås arbeidsenhet
3. Lås feilregler
4. Lås output-format
5. Bygg n8n-trigger
6. Bygg scan
7. Bygg route
8. Bygg rapport
