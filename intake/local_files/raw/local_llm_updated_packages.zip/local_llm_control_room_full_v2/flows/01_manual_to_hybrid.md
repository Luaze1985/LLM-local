---
title: Manual to hybrid flow
date: 2026-04-06
status: draft
tags: [flow, manual, hybrid]
category: architecture
chunk_type: flow
---

# Manual to hybrid flow

1. Lokal scan
2. Lokal forklaring av README
3. Lokal analyse av én fil
4. Vurder om oppgaven fortsatt er liten
5. Hvis nei: skriv handoff
6. Send handoff til Claude eller Codex
7. Gjør én avgrenset endring
