---
title: Hybrid handoff template
date: 2026-04-06
status: draft
tags: [template, handoff, hybrid]
category: architecture
chunk_type: template
---

# Goal

# Selected area

# What local analysis found

# What is still uncertain

# Why this should go to Claude or Codex now

# Next bounded task
