param(
  [Parameter(Mandatory=$true)][string]$RepoPath,
  [string]$Model = "qwen3:14b",
  [string]$Task = "Forklar prosjektet, velg viktigste fil, og pek på én liten forbedring"
)

Set-Location "$PSScriptRoot\..\reference\stifinner_mvp"
python .\stifinner.py init --repo "$RepoPath" --model $Model
python .\stifinner.py step --repo "$RepoPath" --task "$Task"
python .\stifinner.py report --repo "$RepoPath"
