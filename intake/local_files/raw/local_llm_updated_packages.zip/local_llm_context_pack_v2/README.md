---
title: Local LLM context pack
date: 2026-04-06
status: revised
tags: [local-llm, workflow, windows, ubuntu, claude, codex, github-qa]
category: architecture
chunk_type: packet
---

# Local LLM context pack

Dette er en oppdatert arbeidsmappe for ditt lokale LLM-spor.

Denne versjonen er kvalitetssikret mot en kuratert GitHub-runde med 34 relevante repoer innen lokal inferens, coding agents, gateway-lag, RAG og senere automatisering.

## Oppdatert kjernebeslutning

Start på Windows først.

Bruk:
- Ollama som primær lokal motor
- Qwen3-Coder som første modellfamilie
- terminal og liten controller som hovedflate
- hybrid håndoff bare når lokal scanning faktisk har gjort nytte

Ikke start med:
- n8n som hovedmotor
- full autonom agent
- hele repoet i ett kall
- Ubuntu før Windows faktisk er en flaskehals

## Hva som er nytt i v2

- GitHub-QA som egen del
- oppdatert modellrangering for april 2026
- tydeligere standardstack
- GitHub-klar handoff for repoet `LLM-local`
- samlet zip-pakke for videre bruk i prosjekt eller repo

## Pakken inneholder

- use case brief
- concept note
- prosjektklar context packet
- Windows-først workflow
- Ubuntu-senere vurdering
- controller-spesifikasjon
- testmatrise
- Claude-byggprompt
- GitHub-QA-validering
- modell- og stackanbefaling
- GitHub-handoff-notat
- enkel PowerShell-starter
- referansekopi av `stifinner_mvp`

## Anbefalt startrekkefølge

1. Les `docs/01_use_case_brief.md`
2. Les `docs/04_windows_first_workflow.md`
3. Les `docs/10_github_qa_validation.md`
4. Les `docs/11_model_and_stack_recommendation_april_2026.md`
5. Kjør `scripts/run_first_test.ps1`
6. Se rapport i repoets `.stifinner/`
7. Vurder først deretter om du trenger hybrid sky eller Ubuntu
