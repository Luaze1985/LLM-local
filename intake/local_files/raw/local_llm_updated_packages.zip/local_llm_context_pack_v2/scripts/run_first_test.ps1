param(
  [Parameter(Mandatory=$true)]
  [string]$RepoPath,

  [string]$Model = "qwen3:14b",

  [string]$Task = "Forklar prosjektet presist og vurder om denne filen hjelper med å forstå eller forbedre repoet"
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RootDir = Split-Path -Parent $ScriptDir
$Stifinner = Join-Path $RootDir "reference\stifinner_mvp\stifinner.py"

Write-Host "[1/4] Init"
python $Stifinner init --repo $RepoPath --model $Model

Write-Host "[2/4] Første steg"
python $Stifinner step --repo $RepoPath --task $Task

Write-Host "[3/4] Fortsett ett steg"
python $Stifinner continue --repo $RepoPath --task $Task

Write-Host "[4/4] Lag rapport"
python $Stifinner report --repo $RepoPath

Write-Host "Ferdig. Se rapport i $RepoPath\.stifinner\report.md"
