param(
  [Parameter(Mandatory=$true)] [string]$RepoPath,
  [Parameter(Mandatory=$false)] [string]$Model = "qwen3:14b"
)

$task = "Forklar prosjektet presist og vurder om denne filen hjelper med å forstå, reprodusere eller forbedre repoet"

python .\stifinner.py init --repo $RepoPath --model $Model
python .\stifinner.py status --repo $RepoPath
python .\stifinner.py step --repo $RepoPath --task $task
python .\stifinner.py continue --repo $RepoPath --task $task
python .\stifinner.py report --repo $RepoPath
