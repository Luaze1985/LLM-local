# Stifinner MVP

En enkel, terminalbasert controller for store repoer og skjøre lokale LLM-kall.

Formålet er å gi modellen små, kontrollerte steg i stedet for å sende hele repoet i ett kall.

## Hva den gjør

- scanner repoet lokalt
- prioriterer README og viktige filer
- sender én fil om gangen til Ollama
- bruker strukturert JSON-svar for enklere validering
- lagrer state i `.stifinner/state.json`
- lagrer ett resultat per steg i `.stifinner/results/`
- kan gjenopptas med `step` / `continue`
- lager en enkel Markdown-rapport

## Krav

- Windows med Python 3.10+
- Ollama kjører lokalt
- modellen finnes i `ollama list`
- repoet ligger lokalt på disken

Det brukes bare Python-standardbibliotek. Ingen `pip install` trengs.

## Viktig om Ollama

Scriptet bruker Ollama sitt `/api/chat`-endepunkt med:
- `stream: false`
- `keep_alive`
- strukturert JSON-schema i `format`

Dette matcher dokumenterte mønstre i Ollama-dokumentasjonen for enklere og mer robust behandling av korte, strukturerte kall. citeturn901706search0turn901706search2turn901706search3

## Første test på Windows PowerShell

Sjekk at Ollama lever:

```powershell
ollama list
```

Eksempel med repo `kommune-task`:

```powershell
cd C:\stifinner_mvp
python .\stifinner.py init --repo "C:\path\til\kommune-task" --model qwen3:14b
python .\stifinner.py status --repo "C:\path\til\kommune-task"
python .\stifinner.py step --repo "C:\path\til\kommune-task" --task "Forklar prosjektet presist og vurder om denne filen hjelper med å forstå eller forbedre repoet"
python .\stifinner.py continue --repo "C:\path\til\kommune-task" --task "Forklar prosjektet presist og vurder om denne filen hjelper med å forstå eller forbedre repoet"
python .\stifinner.py report --repo "C:\path\til\kommune-task"
```

## Hvordan arbeidsflyten ser ut

1. `init`
   - oppretter `.stifinner`
   - scanner repoet
   - lagrer state
2. `step`
   - velger README først, deretter neste viktige fil
   - kutter for lange filer
   - sender ett kontrollert kall til modellen
   - lagrer resultat og peker til neste fil
3. `continue`
   - samme som `step`, bare videre
4. `report`
   - lager en enkel rapport i Markdown

## Når du bør bruke dette

Bruk dette når du vil teste om modellen kan:
- forstå repoet
- forklare sentrale filer riktig
- foreslå forbedringer i små steg
- jobbe uten at ett langt kall ødelegger hele flyten

## Når du ikke bør bruke dette

Ikke bruk dette som autonom agent for:
- store refaktorer i ett steg
- automatisk patching rett i repoet
- full CI/CD
- full RAG

Dette er en kontrollert MVP.

## Vanlige feil

### 1. Timeout
Prøv kortere timeout først, eller mindre filer via `--file`.

### 2. Feil modellnavn
Bruk nøyaktig samme navn som `ollama list` viser.

### 3. Ingen README funnet
Det går fint. Scriptet går videre til andre viktige filer.

### 4. Dårlig JSON fra modellen
Kjør samme steg igjen. Om det fortsatt feiler, bruk en enklere modelloppgave eller mindre fil.

## Neste utvidelser

Når denne virker, kan du legge til:
- validator
- retry/fallback-manager
- enkel patch-plan
- testkjøring
