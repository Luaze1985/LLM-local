#!/usr/bin/env python3
import argparse
import json
import os
import sys
import time
import subprocess
import hashlib
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib import request, error

DEFAULT_OLLAMA_URL = "http://localhost:11434/api/chat"
DEFAULT_TIMEOUT = 120
DEFAULT_KEEP_ALIVE = "30m"
DEFAULT_MAX_INPUT_CHARS = 16000
DEFAULT_MAX_FILE_BYTES = 256000
DEFAULT_MAX_FINDINGS = 5
WORK_DIR_NAME = ".stifinner"
STATE_FILE = "state.json"
SCAN_FILE = "scan.json"
RESULTS_DIR = "results"
REPORT_FILE = "report.md"

ALLOWED_EXTS = {
    ".md", ".txt", ".rst", ".py", ".js", ".ts", ".tsx", ".jsx", ".json",
    ".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf", ".ps1", ".sh", ".bat",
    ".go", ".java", ".cs", ".rs", ".php", ".rb", ".html", ".css", ".sql",
}

EXCLUDED_DIRS = {
    ".git", ".hg", ".svn", "node_modules", "dist", "build", ".next", ".nuxt",
    "coverage", ".venv", "venv", "env", "__pycache__", ".mypy_cache", ".pytest_cache",
    ".idea", ".vscode", ".turbo", ".cache", "target", "bin", "obj",
}

IMPORTANT_FILENAMES = {
    "readme.md": 1000,
    "readme.txt": 1000,
    "package.json": 900,
    "package-lock.json": 300,
    "pnpm-lock.yaml": 300,
    "yarn.lock": 300,
    "pyproject.toml": 900,
    "requirements.txt": 800,
    "dockerfile": 700,
    "docker-compose.yml": 700,
    "docker-compose.yaml": 700,
    "compose.yml": 700,
    "compose.yaml": 700,
    "main.py": 650,
    "app.py": 650,
    "server.py": 650,
    "index.ts": 600,
    "index.tsx": 600,
    "index.js": 600,
    "main.ts": 650,
    "main.tsx": 650,
    "main.js": 650,
    "vite.config.ts": 500,
    "next.config.js": 500,
    "tsconfig.json": 500,
}


def eprint(*args: Any) -> None:
    print(*args, file=sys.stderr)


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def sha1_text(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8", errors="ignore")).hexdigest()[:12]


def load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def save_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def save_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        f.write(text)


def work_dir(repo: Path) -> Path:
    return repo / WORK_DIR_NAME


def state_path(repo: Path) -> Path:
    return work_dir(repo) / STATE_FILE


def scan_path(repo: Path) -> Path:
    return work_dir(repo) / SCAN_FILE


def results_dir(repo: Path) -> Path:
    return work_dir(repo) / RESULTS_DIR


def report_path(repo: Path) -> Path:
    return work_dir(repo) / REPORT_FILE


def normalize_repo_path(path_str: str) -> Path:
    p = Path(path_str).expanduser().resolve()
    if not p.exists() or not p.is_dir():
        raise SystemExit(f"Repo path finnes ikke eller er ikke en mappe: {p}")
    return p


def git_ls_files(repo: Path) -> Optional[List[str]]:
    try:
        out = subprocess.check_output(["git", "-C", str(repo), "ls-files"], stderr=subprocess.DEVNULL)
        lines = out.decode("utf-8", errors="ignore").splitlines()
        return [line.strip() for line in lines if line.strip()]
    except Exception:
        return None


def file_priority(rel_path: str, file_size: int) -> int:
    p = Path(rel_path)
    name = p.name.lower()
    score = IMPORTANT_FILENAMES.get(name, 0)
    if "readme" in name:
        score += 500
    parts_lower = [part.lower() for part in p.parts]
    if "src" in parts_lower:
        score += 80
    if "app" in parts_lower:
        score += 60
    if "api" in parts_lower:
        score += 60
    if len(p.parts) <= 2:
        score += 70
    if file_size < 8000:
        score += 80
    elif file_size < 20000:
        score += 50
    elif file_size > 100000:
        score -= 120
    ext = p.suffix.lower()
    if ext in {".md", ".toml", ".json", ".yml", ".yaml"}:
        score += 30
    return score


def scan_repo(repo: Path, max_file_bytes: int = DEFAULT_MAX_FILE_BYTES) -> Dict[str, Any]:
    files = []
    git_files = git_ls_files(repo)
    rel_candidates: List[str]
    if git_files:
        rel_candidates = git_files
    else:
        rel_candidates = []
        for root, dirnames, filenames in os.walk(repo):
            dirnames[:] = [d for d in dirnames if d not in EXCLUDED_DIRS]
            for filename in filenames:
                full = Path(root) / filename
                rel_candidates.append(str(full.relative_to(repo)).replace("\\", "/"))

    for rel in rel_candidates:
        rel_norm = rel.replace("\\", "/")
        path = repo / rel_norm
        if not path.exists() or not path.is_file():
            continue
        if any(part in EXCLUDED_DIRS for part in Path(rel_norm).parts):
            continue
        ext = path.suffix.lower()
        if ext and ext not in ALLOWED_EXTS:
            continue
        try:
            size = path.stat().st_size
        except OSError:
            continue
        if size > max_file_bytes:
            continue
        files.append({
            "path": rel_norm,
            "size": size,
            "priority": file_priority(rel_norm, size),
        })

    files.sort(key=lambda x: (-x["priority"], x["size"], x["path"]))
    readme = next((f["path"] for f in files if Path(f["path"]).name.lower().startswith("readme")), None)
    return {
        "created_at": now_iso(),
        "repo": str(repo),
        "readme": readme,
        "file_count": len(files),
        "files": files,
    }


def initial_state(repo: Path, model: str, ollama_url: str, timeout: int, keep_alive: str,
                  max_input_chars: int, max_findings: int) -> Dict[str, Any]:
    return {
        "repo": str(repo),
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "model": model,
        "ollama_url": ollama_url,
        "timeout_seconds": timeout,
        "keep_alive": keep_alive,
        "max_input_chars": max_input_chars,
        "max_findings": max_findings,
        "processed": [],
        "failed": [],
        "current_index": 0,
        "last_result": None,
        "last_error": None,
        "task": None,
    }


def load_state(repo: Path) -> Dict[str, Any]:
    p = state_path(repo)
    if not p.exists():
        raise SystemExit(f"Ingen state funnet i {p}. Kjør init først.")
    return load_json(p, {})


def save_state(repo: Path, state: Dict[str, Any]) -> None:
    state["updated_at"] = now_iso()
    save_json(state_path(repo), state)


def read_file_preview(path: Path, max_chars: int) -> Tuple[str, bool]:
    raw = path.read_text(encoding="utf-8", errors="ignore")
    if len(raw) <= max_chars:
        return raw, False
    head = raw[: int(max_chars * 0.65)]
    tail = raw[-int(max_chars * 0.25):]
    omitted = len(raw) - len(head) - len(tail)
    preview = (
        head
        + f"\n\n[... {omitted} tegn utelatt for å holde kallet stabilt ...]\n\n"
        + tail
    )
    return preview, True


def next_candidate(scan: Dict[str, Any], state: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    processed = set(state.get("processed", []))
    failed = set(state.get("failed", []))
    files = scan.get("files", [])

    readme = scan.get("readme")
    if readme and readme not in processed and readme not in failed:
        return next((f for f in files if f["path"] == readme), None)

    start = max(0, int(state.get("current_index", 0)))
    for idx in range(start, len(files)):
        candidate = files[idx]
        if candidate["path"] in processed or candidate["path"] in failed:
            continue
        state["current_index"] = idx
        return candidate

    for idx, candidate in enumerate(files):
        if candidate["path"] in processed or candidate["path"] in failed:
            continue
        state["current_index"] = idx
        return candidate
    return None


def build_prompt(task: str, repo: Path, rel_path: str, content: str, truncated: bool, max_findings: int) -> str:
    trunc = "ja" if truncated else "nei"
    return f"""
Du er en kontrollert repo-analytiker.

Mål:
- Vurder om denne filen hjelper med å forstå, presisere, reprodusere eller forbedre kodebasen.
- Vær kort, konkret og teknisk nøktern.
- Ikke dikt opp informasjon som ikke finnes i filen.
- Hvis filen er utilstrekkelig, si det tydelig.
- Hvis filutdraget er kuttet, ta hensyn til det.

Repo:
{repo.name}

Oppgave:
{task}

Fil:
{rel_path}

Er filen avkortet?
{trunc}

Svar KUN som JSON som følger schemaet.
Maks {max_findings} punkter i lister.

Filinnhold:
```\n{content}\n```
""".strip()


def schema(max_findings: int) -> Dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "usable": {"type": "boolean"},
            "summary": {"type": "string"},
            "objective_match": {"type": "string"},
            "findings": {
                "type": "array",
                "items": {"type": "string"},
                "maxItems": max_findings,
            },
            "risks": {
                "type": "array",
                "items": {"type": "string"},
                "maxItems": max_findings,
            },
            "next_files": {
                "type": "array",
                "items": {"type": "string"},
                "maxItems": max_findings,
            },
            "recommended_next_action": {"type": "string"},
            "confidence": {"type": "integer", "minimum": 1, "maximum": 5},
        },
        "required": [
            "usable", "summary", "objective_match", "findings", "risks",
            "next_files", "recommended_next_action", "confidence"
        ],
        "additionalProperties": False,
    }


def ollama_chat(url: str, model: str, prompt: str, timeout_seconds: int,
                keep_alive: str, max_findings: int) -> Dict[str, Any]:
    payload = {
        "model": model,
        "stream": False,
        "keep_alive": keep_alive,
        "format": schema(max_findings),
        "options": {"temperature": 0},
        "messages": [
            {"role": "system", "content": "Du svarer kort og kun med gyldig JSON."},
            {"role": "user", "content": prompt},
        ],
    }
    data = json.dumps(payload).encode("utf-8")
    req = request.Request(url, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    with request.urlopen(req, timeout=timeout_seconds) as resp:
        raw = resp.read().decode("utf-8", errors="ignore")
    outer = json.loads(raw)
    content = outer.get("message", {}).get("content", "")
    result = json.loads(content)
    result["_meta"] = {
        "total_duration_ns": outer.get("total_duration"),
        "load_duration_ns": outer.get("load_duration"),
        "prompt_eval_count": outer.get("prompt_eval_count"),
        "eval_count": outer.get("eval_count"),
        "done_reason": outer.get("done_reason"),
    }
    return result


def process_one(repo: Path, state: Dict[str, Any], scan: Dict[str, Any], task: str,
                explicit_file: Optional[str] = None, timeout_override: Optional[int] = None) -> Dict[str, Any]:
    if explicit_file:
        candidate = next((f for f in scan.get("files", []) if f["path"] == explicit_file.replace("\\", "/")), None)
        if not candidate:
            raise SystemExit(f"Fant ikke fil i scan: {explicit_file}")
    else:
        candidate = next_candidate(scan, state)
        if not candidate:
            raise SystemExit("Ingen flere filer å analysere. Kjør report eller scan på nytt.")

    rel_path = candidate["path"]
    full_path = repo / rel_path
    content, truncated = read_file_preview(full_path, int(state.get("max_input_chars", DEFAULT_MAX_INPUT_CHARS)))
    prompt = build_prompt(task=task, repo=repo, rel_path=rel_path, content=content,
                          truncated=truncated, max_findings=int(state.get("max_findings", DEFAULT_MAX_FINDINGS)))
    timeout_seconds = int(timeout_override or state.get("timeout_seconds", DEFAULT_TIMEOUT))
    model = state.get("model")
    url = state.get("ollama_url", DEFAULT_OLLAMA_URL)
    keep_alive = state.get("keep_alive", DEFAULT_KEEP_ALIVE)
    max_findings = int(state.get("max_findings", DEFAULT_MAX_FINDINGS))

    result: Dict[str, Any]
    try:
        result = ollama_chat(url=url, model=model, prompt=prompt,
                             timeout_seconds=timeout_seconds, keep_alive=keep_alive,
                             max_findings=max_findings)
    except error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="ignore") if hasattr(exc, "read") else ""
        msg = f"HTTP-feil fra Ollama: {exc.code} {exc.reason}. {body[:400]}"
        state["last_error"] = msg
        state.setdefault("failed", []).append(rel_path)
        save_state(repo, state)
        raise SystemExit(msg)
    except Exception as exc:
        msg = f"LLM-kall feilet: {type(exc).__name__}: {exc}"
        state["last_error"] = msg
        state.setdefault("failed", []).append(rel_path)
        save_state(repo, state)
        raise SystemExit(msg)

    out = {
        "id": sha1_text(f"{now_iso()}::{rel_path}::{task}"),
        "created_at": now_iso(),
        "task": task,
        "file": rel_path,
        "file_size": candidate["size"],
        "file_priority": candidate["priority"],
        "truncated": truncated,
        "result": result,
    }
    state.setdefault("processed", []).append(rel_path)
    state["last_result"] = out
    state["last_error"] = None
    state["task"] = task
    state["current_index"] = int(state.get("current_index", 0)) + 1
    save_state(repo, state)
    save_json(results_dir(repo) / f"{out['id']}.json", out)
    return out


def generate_report(repo: Path, state: Dict[str, Any]) -> str:
    rows = []
    for file in sorted(results_dir(repo).glob("*.json")):
        rows.append(load_json(file, {}))

    lines: List[str] = []
    lines.append(f"# Stifinner-rapport for {repo.name}")
    lines.append("")
    lines.append(f"- Opprettet: {now_iso()}")
    lines.append(f"- Modell: {state.get('model')}")
    lines.append(f"- Oppgave: {state.get('task')}")
    lines.append(f"- Behandlede filer: {len(state.get('processed', []))}")
    lines.append(f"- Feilede filer: {len(state.get('failed', []))}")
    lines.append("")

    if state.get("last_error"):
        lines.append("## Siste feil")
        lines.append("")
        lines.append(state["last_error"])
        lines.append("")

    lines.append("## Sammendrag per fil")
    lines.append("")
    for row in rows:
        result = row.get("result", {})
        lines.append(f"### {row.get('file')}")
        lines.append("")
        lines.append(f"- Brukbar: {result.get('usable')}")
        lines.append(f"- Tillit: {result.get('confidence')}/5")
        lines.append(f"- Kort oppsummering: {result.get('summary', '').strip()}")
        lines.append(f"- Neste handling: {result.get('recommended_next_action', '').strip()}")
        findings = result.get("findings", []) or []
        risks = result.get("risks", []) or []
        next_files = result.get("next_files", []) or []
        if findings:
            lines.append("- Funn:")
            for item in findings:
                lines.append(f"  - {item}")
        if risks:
            lines.append("- Risiko:")
            for item in risks:
                lines.append(f"  - {item}")
        if next_files:
            lines.append("- Neste filer:")
            for item in next_files:
                lines.append(f"  - {item}")
        lines.append("")

    report = "\n".join(lines).rstrip() + "\n"
    save_text(report_path(repo), report)
    return report


def cmd_init(args: argparse.Namespace) -> None:
    repo = normalize_repo_path(args.repo)
    wd = work_dir(repo)
    wd.mkdir(parents=True, exist_ok=True)
    (wd / RESULTS_DIR).mkdir(parents=True, exist_ok=True)
    scan = scan_repo(repo, max_file_bytes=args.max_file_bytes)
    state = initial_state(
        repo=repo,
        model=args.model,
        ollama_url=args.ollama_url,
        timeout=args.timeout,
        keep_alive=args.keep_alive,
        max_input_chars=args.max_input_chars,
        max_findings=args.max_findings,
    )
    save_json(scan_path(repo), scan)
    save_state(repo, state)
    print(f"Init ferdig for {repo}")
    print(f"Arbeidsmappe: {work_dir(repo)}")
    print(f"Filer i scan: {scan['file_count']}")
    print(f"README: {scan.get('readme') or 'ikke funnet'}")
    if scan.get("files"):
        print("Topp 10 kandidater:")
        for item in scan["files"][:10]:
            print(f"  - {item['path']} (prio {item['priority']}, {item['size']} bytes)")


def cmd_scan(args: argparse.Namespace) -> None:
    repo = normalize_repo_path(args.repo)
    scan = scan_repo(repo, max_file_bytes=args.max_file_bytes)
    save_json(scan_path(repo), scan)
    print(f"Scan oppdatert. {scan['file_count']} filer registrert.")
    for item in scan["files"][:20]:
        print(f"  - {item['path']} (prio {item['priority']}, {item['size']} bytes)")


def cmd_status(args: argparse.Namespace) -> None:
    repo = normalize_repo_path(args.repo)
    state = load_state(repo)
    scan = load_json(scan_path(repo), {})
    print(f"Repo: {repo}")
    print(f"Modell: {state.get('model')}")
    print(f"Ollama URL: {state.get('ollama_url')}")
    print(f"Oppgave: {state.get('task')}")
    print(f"Behandlede filer: {len(state.get('processed', []))}")
    print(f"Feilede filer: {len(state.get('failed', []))}")
    print(f"README: {scan.get('readme')}")
    candidate = next_candidate(scan, state)
    print(f"Neste kandidat: {candidate['path'] if candidate else 'ingen'}")
    if state.get("last_error"):
        print(f"Siste feil: {state['last_error']}")


def cmd_step(args: argparse.Namespace) -> None:
    repo = normalize_repo_path(args.repo)
    state = load_state(repo)
    scan = load_json(scan_path(repo), {})
    if not scan:
        raise SystemExit("Ingen scan funnet. Kjør init eller scan først.")
    result = process_one(repo=repo, state=state, scan=scan, task=args.task,
                         explicit_file=args.file, timeout_override=args.timeout)
    print(f"Ferdig: {result['file']}")
    print(json.dumps(result["result"], ensure_ascii=False, indent=2))


def cmd_continue(args: argparse.Namespace) -> None:
    return cmd_step(args)


def cmd_reset(args: argparse.Namespace) -> None:
    repo = normalize_repo_path(args.repo)
    state = load_state(repo)
    state["processed"] = []
    state["failed"] = []
    state["current_index"] = 0
    state["last_result"] = None
    state["last_error"] = None
    save_state(repo, state)
    for file in results_dir(repo).glob("*.json"):
        file.unlink(missing_ok=True)
    rp = report_path(repo)
    if rp.exists():
        rp.unlink()
    print("State og resultater nullstilt.")


def cmd_report(args: argparse.Namespace) -> None:
    repo = normalize_repo_path(args.repo)
    state = load_state(repo)
    report = generate_report(repo, state)
    print(report)
    print(f"Rapport lagret i {report_path(repo)}")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Stifinner MVP – kontrollert CLI-controller for store repoer og skjøre LLM-kall"
    )
    sub = p.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="Opprett state og første scan")
    init.add_argument("--repo", required=True, help="Path til lokalt repo")
    init.add_argument("--model", required=True, help="Ollama-modellnavn, f.eks. qwen3:14b")
    init.add_argument("--ollama-url", default=DEFAULT_OLLAMA_URL, help=f"Ollama chat URL. Default: {DEFAULT_OLLAMA_URL}")
    init.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT, help=f"Timeout per kall i sekunder. Default: {DEFAULT_TIMEOUT}")
    init.add_argument("--keep-alive", default=DEFAULT_KEEP_ALIVE, help=f"Ollama keep_alive. Default: {DEFAULT_KEEP_ALIVE}")
    init.add_argument("--max-input-chars", type=int, default=DEFAULT_MAX_INPUT_CHARS, help=f"Maks tegn sendt per steg. Default: {DEFAULT_MAX_INPUT_CHARS}")
    init.add_argument("--max-file-bytes", type=int, default=DEFAULT_MAX_FILE_BYTES, help=f"Maks filstørrelse i scan. Default: {DEFAULT_MAX_FILE_BYTES}")
    init.add_argument("--max-findings", type=int, default=DEFAULT_MAX_FINDINGS, help=f"Maks antall funn/risikoer. Default: {DEFAULT_MAX_FINDINGS}")
    init.set_defaults(func=cmd_init)

    scan = sub.add_parser("scan", help="Kjør scan på nytt")
    scan.add_argument("--repo", required=True)
    scan.add_argument("--max-file-bytes", type=int, default=DEFAULT_MAX_FILE_BYTES)
    scan.set_defaults(func=cmd_scan)

    status = sub.add_parser("status", help="Vis status")
    status.add_argument("--repo", required=True)
    status.set_defaults(func=cmd_status)

    step = sub.add_parser("step", help="Analyser neste fil eller en valgt fil")
    step.add_argument("--repo", required=True)
    step.add_argument("--task", required=True, help="Kort og konkret oppgave")
    step.add_argument("--file", help="Valgfri spesifikk fil relativt til repo")
    step.add_argument("--timeout", type=int, help="Overstyr timeout for dette kallet")
    step.set_defaults(func=cmd_step)

    cont = sub.add_parser("continue", help="Alias for step")
    cont.add_argument("--repo", required=True)
    cont.add_argument("--task", required=True)
    cont.add_argument("--file")
    cont.add_argument("--timeout", type=int)
    cont.set_defaults(func=cmd_continue)

    reset = sub.add_parser("reset", help="Nullstill state og resultater")
    reset.add_argument("--repo", required=True)
    reset.set_defaults(func=cmd_reset)

    report = sub.add_parser("report", help="Lag Markdown-rapport")
    report.add_argument("--repo", required=True)
    report.set_defaults(func=cmd_report)

    return p


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
