---
title: Model and stack recommendation april 2026
date: 2026-04-06
status: final
tags: [models, stack, recommendation, april-2026]
category: architecture
chunk_type: decision
---

# Model and stack recommendation april 2026

## Førstevalg

### Runtime
- **Ollama**

### Modell
- **Qwen3-Coder** som første familie
- praktisk reserve: **Qwen3-Coder-30B-A3B-Instruct**
- moden fallback: **Qwen2.5-Coder**

## Reservevalg

### Bred lokal gateway
- **LocalAI**

### Desktop med lokal API
- **Jan**

### Hybrid API-lag
- **LiteLLM**

## Repoarbeid

### Første arbeidsmønster
- liten controller
- terminal først
- state per steg
- én fil per arbeidsenhet først

### Verktøy som peker i riktig retning
- **Aider** for terminal-først repoarbeid
- **Cline** for IDE-agent og mer visuelt agentarbeid

## Ikke førstevalg

- OpenHands som første lag
- AnythingLLM som første repoanalyseflate
- n8n som første motor

De kan bli nyttige senere, men de bør ikke være stedet du finner ut hva som faktisk virker.

## Praktisk anbefaling

Standardstack for deg nå:

1. Ollama
2. Qwen3-Coder
3. lokal controller
4. rapport og state
5. LiteLLM bare når lokal + sky skal samles
6. n8n senere
