---
title: Local LLM execution controller concept note
date: 2026-04-06
status: draft
tags: [concept, local-llm, execution-controller]
category: architecture
chunk_type: concept
---

# Concept

Konseptet er en liten lokal execution controller som legger seg mellom repoet og modellen. Den skal styre hvor mye input modellen får, hvilke filer som velges, hvor lenge et kall får løpe, hva som lagres, og når arbeidet skal deles opp, stoppes eller sendes videre til en sterkere modell. Modellen er motoren. Controlleren er gir, bremser, instrumentpanel og nødstopp.

# Problem

Lokale LLM-er feiler ofte ikke fordi modellen er ubrukelig, men fordi arbeidsformen er for bred: for stor kontekst, for lange kall, for løs styring, for lite state og for svak validering. Resultatet blir heng, timeout, ubrukelig output eller tap av fremdrift.

# Inputs

- source note: tidligere tråd om n8n, Ollama, Claude Code, Codex og hybrid arbeidsform
- source note: eksisterende `stifinner_mvp`-pakke som allerede følger et lite kontrollert repo-mønster

# Shape

- target users:
  - deg selv som ikke vil begynne på nytt hver gang
  - senere også andre agenter eller kodeverktøy som trenger samme kontrollsløyfe
- main workflow:
  - scan -> velg liten arbeidsenhet -> kall modell -> valider -> lagre -> fortsett eller stopp
- likely outputs:
  - repoanalyse
  - forklaring av nøkkelfiler
  - små forbedringsforslag
  - rapport og håndoff-notater

# Open Questions

- question: når er lokal modell god nok, og når skal oppgaven rutes til sky?
- question: når blir Ubuntu faktisk nødvendig, og hva er objektive tegn på at Windows er flaskehalsen?
