---
title: n8n later not now
date: 2026-04-06
status: draft
tags: [n8n, workflow, decision]
category: architecture
chunk_type: decision
---

# n8n senere, ikke nå

n8n er nyttig når arbeidsflyten allerede er stabil og skal kjøres igjen og igjen.

Det er ikke riktig første lag for dette prosjektet fordi du ellers feilsøker flere ting samtidig:

- modell
- prompt
- filvalg
- timeout
- state
- container/nettverk
- workflow-node-oppsett

## Når n8n blir riktig

Legg på n8n først når:

- lokal CLI-test virker stabilt
- du vet hvilke steg som faktisk skal automatiseres
- du vet hvilke feil som er normale
- du vet hva som skal logges og hva som skal ignoreres

## Første gode n8n-bruk senere

- kjøre daglig scan av nye filer
- sende små filer til lokal modell
- lagre markdown-rapporter
- bare rute høyverdioppgaver videre til sky
