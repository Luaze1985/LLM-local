---
title: Local vs hybrid test matrix
date: 2026-04-06
status: draft
tags: [test, matrix, local-llm, hybrid]
category: architecture
chunk_type: eval
---

# Test matrix

## Nivå 1 – Forståelse

Oppgave:
- gi modellen README
- be den forklare prosjektet

Bestått når:
- forklaringen er presis nok til at du kjenner igjen repoet
- modellen peker på riktige hoveddeler

## Nivå 2 – Filforståelse

Oppgave:
- gi modellen én sentral fil
- be den forklare filens rolle

Bestått når:
- forklaringen stemmer med det du ser i filen
- modellen peker ut reell funksjon, ikke bare generisk kodeprat

## Nivå 3 – Presisering

Oppgave:
- gi README + én fil
- be om tydeligere beskrivelse av hvordan systemet faktisk henger sammen

Bestått når:
- modellen rydder opp i uklarheter
- outputen kan brukes som notat eller håndoff

## Nivå 4 – Liten forbedring

Oppgave:
- be om én liten forbedring med lav risiko

Bestått når:
- forbedringen er konkret
- den virker realistisk
- den sprenger ikke rammene for en lokal modell

## Nivå 5 – Handoff-beslutning

Etter disse fire nivåene tar du beslutningen:

- behold oppgaven lokalt
- send bare forbedringssteget til sky
- send hele neste blokk til sky

## Poengskala

Bruk enkel skala 0–2 på hvert nivå:

- 0 = mislykket
- 1 = delvis nyttig
- 2 = tydelig nyttig

Total:
- 0–3: for ustabilt, del opp mer
- 4–6: godt nok for scanning og forklaring
- 7–8: godt nok for små forbedringer
- 9–10: kandidat for mer selvstendig lokal bruk
