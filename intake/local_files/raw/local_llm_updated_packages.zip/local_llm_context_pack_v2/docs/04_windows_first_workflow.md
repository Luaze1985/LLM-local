---
title: Windows first workflow for local LLMs
date: 2026-04-06
status: revised
tags: [workflow, windows, ollama, terminal]
category: architecture
chunk_type: process
---

# Windows-first workflow

## Prinsipp

Start med det som allerede er nærmest virkeligheten din:

- Windows
- Ollama lokalt
- Qwen3-Coder som første modell
- terminal
- ett lokalt repo
- liten modelloppgave

Ikke gjør Ubuntu, n8n eller full agent til første problem.

## Arbeidsflyt

### 1. Velg ett repo

Velg ett repo du bryr deg om, ikke et tilfeldig demo-repo.

Første gode oppgave:
- forklar prosjektet presist
- forklar de viktigste filene
- pek på én liten forbedring

### 2. Test grunnmur

Kjør i terminal:

```powershell
ollama list
ollama ps
```

Hvis modellen finnes og kan lastes, går du videre.

### 3. Kjør controlleren

Bruk den medfølgende `stifinner_mvp`-referansen.

```powershell
python .\reference\stifinner_mvp\stifinner.py init --repo "C:\path\til\repo" --model qwen3:14b
python .\reference\stifinner_mvp\stifinner.py step --repo "C:\path\til\repo" --task "Forklar prosjektet presist og vurder om denne filen hjelper med å forstå eller forbedre repoet"
python .\reference\stifinner_mvp\stifinner.py continue --repo "C:\path\til\repo" --task "Forklar prosjektet presist og vurder om denne filen hjelper med å forstå eller forbedre repoet"
python .\reference\stifinner_mvp\stifinner.py report --repo "C:\path\til\repo"
```

### 4. Les rapport, ikke bare råsvaret

Se spesielt etter:

- stoppet modellen?
- kom JSON/strukturert svar tilbake?
- var forklaringen brukbar?
- ble riktig fil valgt?
- ble state lagret?

### 5. Ta ett valg

Etter første test velger du én av tre ruter:

- lokal modell holder for denne oppgaven
- lokal modell holder til scanning, men ikke til forbedring
- lokal modell er for ustabil, og oppgaven må kuttes mer ned eller rutes til sky

## Ikke gjør dette først

- flere repoer samtidig
- 20–40 mapper i én første test
- automatiske patches i repoet
- n8n-loop over alt innhold
- Ubuntu-bygg fordi du antar at det trengs

## Definisjon på vellykket første test

Første test er vellykket hvis du får:

- en meningsfull prosjektforklaring
- 1–3 brukbare filfunn
- lagret state
- ingen total lås eller manuell opprydding
