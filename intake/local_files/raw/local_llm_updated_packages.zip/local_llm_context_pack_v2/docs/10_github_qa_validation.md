---
title: GitHub QA validation
date: 2026-04-06
status: final
tags: [github, qa, validation, local-llm]
category: architecture
chunk_type: evidence
---

# GitHub QA validation

Denne pakken er kvalitetssikret mot en kuratert GitHub-runde med 34 repoer.

## Hva QA-runden bekreftet

- lokal controller først er riktig
- hybrid lokal + Claude/Codex er riktig andre lag
- n8n er riktig senere lag, ikke første arbeidsflate
- Qwen3-Coder er sterkeste åpne lokale kodemodell-signal i denne runden
- Ollama er det reneste førstevalget som lokal runtime
- LocalAI er den beste brede reserve for flere backends og mer variert maskinvare
- LiteLLM er nyttig når lokal og sky skal samles i ett API-lag

## Viktigste repoer

### Score 5
- `ollama/ollama`
- `Aider-AI/aider`
- `cline/cline`
- `QwenLM/Qwen3-Coder`
- `mudler/LocalAI`

### Score 4
- `OpenHands/OpenHands`
- `BerriAI/litellm`
- `Mintplex-Labs/anything-llm`
- `janhq/jan`
- `n8n-io/n8n`

## Hva dette betyr for beslutningen

Arbeidsformen bør låses slik:

1. lokal runtime og liten controller først
2. repoanalyse og state lokalt
3. håndoff til Claude/Codex bare når lokal pass faktisk har redusert problemet
4. n8n først når stegene er stabile og repeterbare

## Vedlegg

- full markdown-rapport: `reference/github_local_llm_qa_report.md`
- full csv-rapport: `reference/github_local_llm_qa_report.csv`
