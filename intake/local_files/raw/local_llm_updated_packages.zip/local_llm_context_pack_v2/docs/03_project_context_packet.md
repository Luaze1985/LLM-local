---
title: Local LLM project context packet
date: 2026-04-06
status: draft
tags: [context-packet, project, local-llm]
category: architecture
chunk_type: packet
---

# Project Summary

Dette prosjektet skal bygge en enkel, robust og gjenbrukbar arbeidsform for lokale LLM-er på egen PC. Fokuset er ikke generell AI-chat, men kontrollert arbeid mot repoer, filer og etter hvert kunnskapsbaser. Stabilitet og gjenopptakelse er viktigere enn maksimal autonomi.

# Current Concept

Sterkeste retning nå er en terminalbasert execution controller på Windows først, med Ubuntu som mulig senere ytelsesvei. `stifinner_mvp` fungerer som første operativ referanse, men skal brukes som kontrollert startpunkt, ikke som ferdig endelig system.

# Key Inputs

- file: `reference/stifinner_mvp/stifinner.py`
- file: `docs/04_windows_first_workflow.md`
- file: `docs/06_execution_controller_spec.md`
- file: `docs/07_test_matrix.md`

# Decisions So Far

- decision: terminal først, n8n senere hvis og bare hvis den manuelle flyten er stabil
- decision: Windows først, Ubuntu senere bare ved konkret ytelses- eller driverbehov
- decision: små steg, ikke hele repoet i én prompt
- decision: lokal modell brukes først til forståelse, scanning og små forbedringer
- decision: sky brukes når oppgaven blir flerfils, mer usikker eller krever høyere kvalitet enn lokal modell leverer

# Next Useful Work

1. Kjør første test mot ett lokalt repo.
2. Vurder resultat etter forståelse, stabilitet og nyttighet.
3. Stram inn prompts og inputgrenser.
4. Legg eventuelt til enkel retry- og fallback-logikk.
5. Først deretter vurder hybrid håndoff til Claude Code eller Codex.
