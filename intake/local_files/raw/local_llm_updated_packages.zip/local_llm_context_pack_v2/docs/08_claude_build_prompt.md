---
title: Claude build prompt for controller expansion
date: 2026-04-06
status: draft
tags: [claude, prompt, controller, build]
category: architecture
chunk_type: prompt
---

# Claude build prompt

Bruk denne når du vil be Claude Code eller Claude i chat om å videreutvikle controlleren.

```text
Jeg vil at du skal videreutvikle en enkel terminalbasert execution controller for lokale LLM-er.

Bakgrunn:
- målet er ikke en fri agent
- målet er å kontrollere ressursbruk, stopp, timeout, dårlig output og tap av state
- løsningen skal brukes på store repoer i små steg
- lokal modell brukes først, sky senere bare ved behov
- eksisterende MVP kan skanne repo, prioritere filer, lagre state og lage rapport

Nå vil jeg at du skal foreslå neste minste nyttige versjon.

Svar i denne strukturen:
1. hva som er svakest i dagens MVP
2. hvilken ene forbedring som gir mest effekt nå
3. konkret filstruktur for endringen
4. eksakte endringer i Python-koden
5. hvordan endringen testes
6. hvilke feil den reduserer

Føringer:
- ikke design en stor ny plattform
- ikke legg på n8n, Redis eller database først
- hold deg til en liten og robust CLI-versjon
- stabilitet er viktigere enn fart
- state og gjenopptakelse er viktig
- svar konkret og ingeniørmessig
```
