---
title: Ubuntu later, not first
date: 2026-04-06
status: draft
tags: [ubuntu, windows, decision]
category: architecture
chunk_type: decision
---

# Ubuntu senere, ikke først

Ubuntu er aktuelt hvis du faktisk møter en konkret vegg på Windows.

## Gå til Ubuntu når minst ett av disse er sant

- GPU-akselerasjon på Windows er åpenbart ustabil eller faller ofte tilbake til CPU
- du vil kjøre større modeller enn det som er praktisk i Windows-oppsettet ditt
- du vil ha mer moden driver- og inferensstøtte over tid
- du merker at samme oppgave blir merkbart mer pålitelig i Linux-miljø

## Ikke gå til Ubuntu bare fordi

- du tror "seriøse" lokale oppsett må være Linux
- du vil løse et problem du ennå ikke har målt
- du ikke har testet Windows-flyten først

## Praktisk regel

Windows skal få være hovedmiljø til det motbevises.
Ubuntu er en ytelses- og stabilitetsoppgradering, ikke startpunktet.
