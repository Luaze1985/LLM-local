---
title: Execution controller specification
date: 2026-04-06
status: revised
tags: [controller, spec, local-llm]
category: architecture
chunk_type: spec
---

# Execution controller specification

## Formål

Gi en lokal eller ekstern modell små, kontrollerte og målbare arbeidsenheter, slik at ressursbruk, stopp og kvalitetsfeil håndteres før de ødelegger hele flyten.

## Standard runtime

Primært:
- Ollama
- Qwen3-Coder

Reserve:
- LocalAI når du trenger bredere backend-støtte
- Jan når du vil ha enkel desktop-lokal server

## Kjernekomponenter

### Repo scanner
- finner README og sentrale filer
- ignorerer støy, byggmapper og tunge kataloger
- prioriterer små og relevante filer først

### Task planner
- gjør brede mål om til små steg
- velger én fil eller én liten batch
- legger inn tydelig oppgaveformulering

### Context builder
- kutter input til trygg størrelse
- pakker filinnhold, filsti og oppgave i en stram prompt
- ber om kort og strukturert output

### LLM runner
- kaller lokal modell via Ollama
- bruker timeout, keep_alive og ikke-streaming når det gir mest robust flyt

### Validator
- sjekker om respons kom tilbake
- sjekker om format og innhold er brukbart
- skiller mellom teknisk stopp og kvalitetsstopp

### State manager
- lagrer hva som er gjort
- lagrer hva som feilet
- gjør det mulig å fortsette senere

### Retry / fallback manager
- retry én gang med mindre input
- fallback til enklere oppgave eller annen modell
- stopper heller tidlig enn å forverre rotet

### Reporter
- lager lesbar rapport
- viser hva som ble analysert
- viser hva som fortsatt er uklart

## Stopptyper

- timeout
- tom respons
- avbrutt respons
- ikke-parsebar respons
- irrelevant respons
- ressursfeil

## Regler

- aldri send hele repoet i ett kall
- jobb med én hovedfil om gangen først
- ikke skriv patch uten at analyse og risiko er dokumentert
- hvis samme steg feiler to ganger, del opp oppgaven
- hvis lokal modell fortsatt feiler, ruter du oppgaven videre i stedet for å presse hardere
